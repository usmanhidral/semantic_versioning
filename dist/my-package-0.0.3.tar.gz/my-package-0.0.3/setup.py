from setuptools import setup

__version__ = "0.0.3"

setup(
   name="my-package",
   version=__version__,
   # And so on...
)